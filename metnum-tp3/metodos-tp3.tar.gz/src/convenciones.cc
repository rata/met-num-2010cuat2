#include "convenciones.hpp"

double tolerancia() { return 1e-7; }

std::string dataDirectory() { return "../data"; }
