#ifndef _VECTOR_UTILS_HPP
#define _VECTOR_UTILS_HPP

void imprimir_vector(int n, double* x);

void normalizar(int n, double* x);

bool distintos(int n1, double* x1, int n2, double* x2);

#endif // ifdef _VECTOR_UTILS_HPP
