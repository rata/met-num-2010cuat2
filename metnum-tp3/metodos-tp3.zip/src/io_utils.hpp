#ifndef _IO_UTILS_HPP
#define _IO_UTILS_HPP

#include <fstream>

int leer(char* pags_path, std::ifstream* fpag );

void cerrar(std::ifstream* file);

#endif // ifdef _IO_UTILS_HPP
