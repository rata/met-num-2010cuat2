#ifndef _CONVENCIONES_H
#define _CONVENCIONES_H

#include <string>

double tolerancia();
std::string dataDirectory();

#endif // _CONVENCIONES_H
