#! /bin/bash

minval=32
maxval=126
val=$minval
while [ $val -le $maxval ]
do
        printf "decimal value is %.3d \n" $val
        printf "octal value is %o \n" $val
        octal=$(printf "0%o" $val)
        char=$(echo -e \\${octal})
        printf "char is %c \n" $char
        charnew=$(printf "%c" $char)
	convert -font Courier-New -pointsize 12 -size 11x19 -density 95 -depth 8 label:$charnew `printf "%.3d" $val`.tiff
        ((val=val+1))
done

convert -font Courier-New -pointsize 12 -size 11x19 -density 95 -depth 8 label:' ' 032.tiff
convert -font Courier-New -pointsize 12 -size 11x19 -density 95 -depth 8 label:'*' 042.tiff
convert -font Courier-New -pointsize 12 -size 11x19 -density 95 -depth 8 label:'\\' 092.tiff
